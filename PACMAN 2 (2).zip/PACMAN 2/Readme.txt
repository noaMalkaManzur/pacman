Noa malka manzur id 207375163
shiraz yom tov id 209015395
we added the colors(its was very fun for us)
we asked sarel about the inheritance from point and he said its ok