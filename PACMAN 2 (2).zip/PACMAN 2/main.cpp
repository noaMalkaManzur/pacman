#include "defineGame.h"
#include "gamePlay.h"
bool withColor;

int main() {

	gamePlay run;
	run.switchMenu();
	return 0;
}	

